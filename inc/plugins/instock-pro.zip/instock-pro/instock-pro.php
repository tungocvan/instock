<?php
/**
 * Plugin Name: Instock Pro
 * Plugin URI: https://www.happythemes.com/
 * Description: Add extra features like widgets, metaboxes, and custom Elementor widgets.
 * Version: 1.0.0
 * Author: HappyThemes
 * Author URI: https://www.happythemes.com/
 * Requires at least: 4.6.0
 * Tested up to: 5.4
 *
 * Text Domain: instock-pro
 * Domain Path: /languages/
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Instock_Pro' ) ) {
	/**
	 * Main Instock_Pro Class
	 *
	 * @since  1.0.0
	 * @access public
	 */
	final class Instock_Pro {

		/**
		 * The token.
		 *
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $token = '';

		/**
		 * The version number.
		 *
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $version = '';

		/**
		 * Directory path to the plugin folder.
		 *
		 * @since  1.0.0
		 * @access public
		 * @var    string
		 */
		public $path = '';

		/**
		 * Directory URI to the plugin folder.
		 *
		 * @since  1.0.0
		 * @access public
		 * @var    string
		 */
		public $uri = '';

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {

			static $instance = null;

			if ( is_null( $instance ) ) {
				$instance = new self;
				$instance->setup();
				$instance->includes();
				$instance->setup_actions();
			}

			return $instance;
		}

		/**
		 * Constructor function.
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		private function __construct() {}

		/**
		 * Initial plugin setup.
		 *
		 * @since  1.0.0
		 * @access private
		 * @return void
		 */
		private function setup() {

			$this->token   = 'instock-pro';
			$this->path    = trailingslashit( plugin_dir_path( __FILE__ ) );
			$this->uri     = trailingslashit( plugin_dir_url( __FILE__ ) );
			$this->version = '1.0.0';

			// Use it all over the plugin files.
			define( 'IP_URL', $this->uri );
			define( 'IP_PATH', $this->path );

		}

		/**
		 * Loads include and admin files for the plugin.
		 *
		 * @since  1.0.0
		 * @access private
		 * @return void
		 */
		private function includes() {

			// Load extensions.
			require_once( IP_PATH . 'ext/butterbean/butterbean.php' );
			require_once( IP_PATH . 'ext/kirki/kirki.php' );

			// Load plugin functions.
			require_once( IP_PATH . 'inc/metabox.php' );
			require_once( IP_PATH . 'inc/functions.php' );
			require_once( IP_PATH . 'inc/sidebars.php' );

			if ( class_exists( 'Elementor\Plugin' ) ) {
				require_once( IP_PATH . 'inc/elementor.php' );
			}

		}

		/**
		 * Setup all the things.
		 * @return void
		 */
		private function setup_actions() {

			// Method that runs only when the plugin is activated.
			register_activation_hook( __FILE__, array( $this, 'install' ) );

			// Internationalize the text strings used.
			add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

			// Load custom widgets
			add_action( 'widgets_init', array( $this, 'custom_widgets' ), 10 );

			// Allow shortcodes in text widgets
			add_filter( 'widget_text', 'do_shortcode' );

			// Scripts & styles for the plugin.
			add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ), 999 );
		}

		/**
		 * Load the localisation file.
		 *
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'instock-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?' ), '1.0.0' );
		}

		/**
		 * Installation.
		 * Runs on activation. Logs the version number and assigns a notice message to a WordPress option.
		 *
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function install() {
			$this->_log_version_number();
		}

		/**
		 * Log the plugin version number.
		 *
		 * @access  private
		 * @since   1.0.0
		 * @return  void
		 */
		private function _log_version_number() {
			update_option( $this->token . '-version', $this->version );
		}

		/**
		 * Custom widgets
		 */
		public static function custom_widgets() {

			if ( ! version_compare( PHP_VERSION, '5.6', '>=' ) ) {
				return;
			}

			// Define array of custom widgets for the theme
			$widgets = apply_filters( 'instock_pro_custom_widgets', array(
				'facebook',
				'flickr',
				'recent-posts',
				'social',
				'tags',
				'twitter'
			) );

			// Loop through widgets and load their files
			if ( $widgets && is_array( $widgets ) ) {
				foreach ( $widgets as $widget ) {
					$file = IP_PATH . '/inc/widgets/' . $widget .'.php';
					if ( file_exists ( $file ) ) {
						require_once( $file );
					}
				}
			}

		}

		/**
		 * Enqueue scripts
		 */
		public function scripts() {

			// Load custom widgets stylesheet.
			wp_enqueue_style( 'instock-pro-widgets-style', IP_URL . 'assets/css/widgets.css' );
			if ( is_RTL() ) {
				wp_enqueue_style( 'instock-pro-widgets-style-rtl', IP_URL . 'assets/css/widgets-rtl.css' );
			}

		}

	} // End Class

	Instock_Pro::get_instance();

}
