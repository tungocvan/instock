<?php
/**
 * Adds custom metabox
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The Metabox class
if ( ! class_exists( 'Instock_Pro_Metabox' ) ) {

	/**
	 * Main ButterBean class.  Runs the show.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	final class Instock_Pro_Metabox {

		/**
		 * The post types
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $post_types = '';

		/**
		 * Sets up initial actions.
		 *
		 * @since 1.0.0
		 */
		private function setup_actions() {

			// Post types to add the metabox to
			$this->post_types = apply_filters( 'instock_pro_metaboxes_post_types', array(
				'post',
				'page',
				'product',
				'elementor_library',
			) );

			// Register fields
			add_action( 'butterbean_register', array( $this, 'register' ), 10, 2 );

			// Load scripts and styles for the metaboxes
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			// Sidebar
			add_filter( 'instock_pro_get_sidebar', array( $this, 'get_sidebar' ) );

		}

		/**
		 * Load scripts and styles
		 *
		 * @since 1.0.0
		 */
		public function enqueue_scripts( $hook ) {

			// Only needed on these admin screens
			if ( $hook != 'edit.php' && $hook != 'post.php' && $hook != 'post-new.php' ) {
				return;
			}

			// Get global post
			global $post;

			// Return if post is not object
			if ( ! is_object( $post ) ) {
				return;
			}

			// Post types scripts
			$post_types_scripts = apply_filters( 'instock_pro_metaboxes_post_types_scripts', $this->post_types );

			// Return if wrong post type
			if ( ! in_array( $post->post_type, $post_types_scripts ) ) {
				return;
			}

			// Default style
			wp_enqueue_style( 'instock-pro-metaboxes', IP_URL . 'assets/css/admin.css' );

		}

		/**
		 * Registration callback
		 *
		 * @since 1.0.0
		 */
		public function register( $butterbean, $post_type ) {

			// Post types to add the metabox to
			$post_types = $this->post_types;

			// Register managers, sections, controls, and settings here.
			$butterbean->register_manager(
				'instock_pro_mb_settings',
				array(
					'label'     => esc_html__( 'Settings', 'instock-pro' ),
					'post_type' => $post_types,
					'context'   => 'normal',
					'priority'  => 'high'
				)
			);

			$manager = $butterbean->get_manager( 'instock_pro_mb_settings' );

			$manager->register_section(
				'instock_pro_mb_general',
				array(
					'label' => esc_html__( 'General', 'instock-pro' ),
					'icon'  => 'dashicons-admin-generic'
				)
			);

			$manager->register_control(
				'instock_pro_post_layout', // Same as setting name.
				array(
					'section'       => 'instock_pro_mb_general',
					'type'          => 'select',
					'label'         => esc_html__( 'Content Layout', 'instock-pro' ),
					'description'   => esc_html__( 'Select your custom layout.', 'instock-pro' ),
					'choices'       => array(
						''                  => esc_html__( 'Default', 'instock-pro' ),
						'right-sidebar'     => esc_html__( 'Right Sidebar', 'instock-pro' ),
						'left-sidebar'      => esc_html__( 'Left Sidebar', 'instock-pro' ),
						'full-width'        => esc_html__( 'Full Width', 'instock-pro' ),
						'full-width-narrow' => esc_html__( 'Full Width Narrow', 'instock-pro' )
					),
				)
			);

			$manager->register_setting(
				'instock_pro_post_layout', // Same as control name.
				array(
					'sanitize_callback' => 'sanitize_key',
				)
			);

			$manager->register_control(
				'instock_pro_sidebar', // Same as setting name.
				array(
					'section'       => 'instock_pro_mb_general',
					'type'          => 'select',
					'label'         => esc_html__( 'Sidebar', 'instock-pro' ),
					'description'   => esc_html__( 'Select your custom sidebar.', 'instock-pro' ),
					'choices'       => $this->helpers( 'widget_areas' ),
				)
			);

			$manager->register_setting(
				'instock_pro_sidebar', // Same as control name.
				array(
					'sanitize_callback' => 'sanitize_key',
				)
			);

		}

		/**
		 * Helpers
		 *
		 * @since 1.0.0
		 */
		public static function helpers( $return = NULL ) {

			// Library
			if ( 'library' == $return ) {
				$templates 		= array( esc_html__( 'Select a Template', 'instock-pro' ) );
				$get_templates 	= get_posts( array( 'post_type' => 'ip_library', 'numberposts' => -1, 'post_status' => 'publish' ) );

				if ( ! empty ( $get_templates ) ) {
					foreach ( $get_templates as $template ) {
						$templates[ $template->ID ] = $template->post_title;
					}
				}

				return $templates;
			}

			// Widgets
			elseif ( 'widget_areas' == $return ) {
				global $wp_registered_sidebars;
				$widgets_areas = array( esc_html__( 'Default', 'instock-pro' ) );
				$get_widget_areas = $wp_registered_sidebars;
				if ( ! empty( $get_widget_areas ) ) {
					foreach ( $get_widget_areas as $widget_area ) {
						$name = isset ( $widget_area['name'] ) ? $widget_area['name'] : '';
						$id = isset ( $widget_area['id'] ) ? $widget_area['id'] : '';
						if ( $name && $id ) {
							$widgets_areas[$id] = $name;
						}
					}
				}
				return $widgets_areas;
			}

		}

		/**
		 * Returns the correct sidebar ID
		 *
		 * @since  1.0.0
		 */
		public function get_sidebar( $sidebar ) {

			if ( $meta = get_post_meta( instock_pro_post_id(), 'instock_pro_sidebar', true ) ) {
				$sidebar = $meta;
			}

			return $sidebar;

		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			static $instance = null;
			if ( is_null( $instance ) ) {
				$instance = new self;
				$instance->setup_actions();
			}
			return $instance;
		}

		/**
		 * Constructor method.
		 *
		 * @since  1.0.0
		 * @access private
		 * @return void
		 */
		private function __construct() {}

	}

	Instock_Pro_Metabox::get_instance();

}
