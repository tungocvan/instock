<?php
/**
 * Elementor functions
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The Metabox class
if ( ! class_exists( 'Instock_Pro_Elementor' ) ) {

	/**
	 * Elementor functions.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	final class Instock_Pro_Elementor {

		/**
		 * Sets up initial actions.
		 */
		private function setup_actions() {

			// Add new category for Elementor
			add_action( 'elementor/init', array( $this, 'elementor_init' ), 1 );

			// Add the action here so that the widgets are always visible
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ) );

			// Front-end Scripts
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_scripts' ) );
			add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_styles' ) );

			// Preview Styles
			add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_styles' ) );

		}

		/**
		 * Add new category for Elementor.
		 */
		public function elementor_init() {

			$elementor = \Elementor\Plugin::$instance;

			// Add element category in panel
			$elementor->elements_manager->add_category(
				'instock_pro_elements',
				[
					'title' => esc_attr__( 'Instock Blocks', 'instock-pro' ),
					'icon' => 'font',
				],
				1
			);
		}

		/**
		 * Register the custom Elementor widgets
		 */
		public function widgets_registered() {

			// We check if the Elementor plugin has been installed / activated.
			if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {

				// Define dir
				$dir = IP_PATH . 'inc/elementor-widgets/';

				// Array of new widgets
				$build_widgets = apply_filters( 'instock_pro_widgets', array(
					'post'               => $dir . 'post.php',
					'post_list'          => $dir . 'post-list.php',
					'post_grid'          => $dir . 'post-grid.php',
					'post_alt'           => $dir . 'post-alt.php',
					'products_carousel'  => $dir . 'products-carousel.php',
				) );

				// Load files
				foreach ( $build_widgets as $widget_filename ) {
					include $widget_filename;
				}

			}

		}

		/**
		 * Register scripts
		 */
		public function register_scripts() {
			wp_register_script( 'owl-carousel', IP_URL . 'assets/js/owl.carousel.min.js', array( 'jquery' ), false, true );

			// Product carousel
			wp_register_script( 'products-carousel', IP_URL . 'assets/js/carousel.js', array( 'jquery' ), false, true );
		}

		/**
		 * Register styles
		 */
		public function register_styles() {
			wp_register_style( 'owl-carousel', IP_URL . 'assets/css/owl.carousel.min.css' );
			wp_register_style( 'owl-carousel-theme', IP_URL . 'assets/css/owl.theme.default.css' );
		}

		/**
		 * Enqueue styles in the editor
		 */
		public function preview_styles() {
			wp_enqueue_style( 'owl-carousel' );
			wp_enqueue_style( 'owl-carousel-theme' );
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			static $instance = null;
			if ( is_null( $instance ) ) {
				$instance = new self;
				$instance->setup_actions();
			}
			return $instance;
		}

		/**
		 * Constructor method.
		 *
		 * @since  1.0.0
		 * @access private
		 * @return void
		 */
		private function __construct() {}

	}

	Instock_Pro_Elementor::get_instance();

}
