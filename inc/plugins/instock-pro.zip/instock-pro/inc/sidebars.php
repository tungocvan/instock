<?php
/**
 * Custom Sidebars
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Start Class
if ( ! class_exists( 'Instock_Pro_Sidebars' ) ) {

	/**
	 * Custom sidebar functions
	 *
	 * @since  1.0.0
	 * @access public
	 */
	final class Instock_Pro_Sidebars {

		private $widget_areas = array();
		private $orig         = array();

		/**
		 * Start things up
		 *
		 * @since 1.0.0
		 */
		private function setup_actions( $widget_areas = array() ) {
			add_action( 'init', array( $this, 'register_custom_widget_areas' ) , 1000 );
			add_action( 'admin_print_scripts-widgets.php', array( $this, 'add_widget_box' ) );
			add_action( 'load-widgets.php', array( $this, 'add_widget_area' ), 100 );
			add_action( 'load-widgets.php', array( $this, 'scripts' ), 100 );
			add_action( 'admin_print_styles-widgets.php', array( $this, 'inline_css' ) );
			add_action( 'wp_ajax_instock_pro_delete_widget_area', array( $this, 'instock_pro_delete_widget_area' ) );
			add_action( 'wp_ajax_nopriv_instock_pro_delete_widget_area', array( $this, 'instock_pro_delete_widget_area' ) );
		}

		/**
		 * Add the widget box inside a script
		 *
		 * @since 1.0.0
		 */
		public function add_widget_box() {
			$nonce = wp_create_nonce ( 'delete-instock-pro-widget_area-nonce' ); ?>
			<script type="text/html" id="instock-pro-add-widget-template">
				<div id="instock-pro-add-widget" class="widgets-holder-wrap">
					<div class="">
						<input type="hidden" name="instock-pro-nonce" value="<?php echo $nonce ?>" />
						<div class="sidebar-name">
							<h3><?php echo __( 'Create Widget Area', 'instock-pro' ); ?> <span class="spinner"></span></h3>
						</div>
						<div class="sidebar-description">
							<form id="addWidgetAreaForm" action="" method="post">
								<div class="widget-content">
									<input id="instock-pro-add-widget-input" name="instock-pro-add-widget-input" type="text" class="regular-text" title="<?php echo __( 'Name', 'instock-pro' ); ?>" placeholder="<?php echo __( 'Name', 'instock-pro' ); ?>" />
								</div>
								<div class="widget-control-actions">
									<div class="aligncenter">
										<input class="addWidgetArea-button button-primary" type="submit" value="<?php echo __( 'Create Widget Area', 'instock-pro' ); ?>" />
									</div>
									<br class="clear">
								</div>
							</form>
						</div>
					</div>
				</div>
			</script>
			<?php
		}

		/**
		 * Create new Widget Area
		 *
		 * @since 1.0.0
		 */
		public function add_widget_area() {
			if ( ! empty( $_POST['instock-pro-add-widget-input'] ) ) {
				$this->widget_areas = $this->get_widget_areas();
				array_push( $this->widget_areas, $this->check_widget_area_name( $_POST['instock-pro-add-widget-input'] ) );
				$this->save_widget_areas();
				wp_redirect( admin_url( 'widgets.php' ) );
				die();
			}
		}

		/**
		 * Before we create a new widget_area, verify it doesn't already exist. If it does, append a number to the name.
		 *
		 * @since 1.0.0
		 */
		public function check_widget_area_name( $name ) {
			if ( empty( $GLOBALS['wp_registered_widget_areas'] ) ) {
				return $name;
			}

			$taken = array();
			foreach ( $GLOBALS['wp_registered_widget_areas'] as $widget_area ) {
				$taken[] = $widget_area['name'];
			}

			$taken = array_merge( $taken, $this->widget_areas );

			if ( in_array( $name, $taken ) ) {
				$counter  = substr( $name, -1 );
				$new_name = '';

				if ( ! is_numeric( $counter ) ) {
					$new_name = $name . ' 1';
				} else {
					$new_name = substr( $name, 0, -1 ) . ((int) $counter + 1);
				}

				$name = $this->check_widget_area_name( $new_name );
			}
			echo $name;
			exit();
			return $name;
		}

		public function save_widget_areas() {
			set_theme_mod( 'instock-pro-sidebars', array_unique( $this->widget_areas ) );
		}

		/**
		 * Register and display the custom widget_area areas we have set.
		 *
		 * @since 1.0.0
		 */
		public function register_custom_widget_areas() {

			// Get widget areas
			if ( empty( $this->widget_areas ) ) {
				$this->widget_areas = $this->get_widget_areas();
			}

			// Original widget areas is empty
			$this->orig = array();

			// Save widget areas
			if ( ! empty( $this->orig ) && $this->orig != $this->widget_areas ) {
				$this->widget_areas = array_unique( array_merge( $this->widget_areas, $this->orig ) );
				$this->save_widget_areas();
			}

			// If widget areas are defined add a sidebar area for each
			if ( is_array( $this->widget_areas ) ) {
				foreach ( array_unique( $this->widget_areas ) as $widget_area ) {
					$args = array(
						'id'			=> sanitize_key( $widget_area ),
						'name'			=> $widget_area,
						'class'			=> 'instock-pro-custom-sidebar',
						'before_widget' => '<aside id="%1$s" class="widget %2$s">',
						'after_widget'  => '</aside>',
						'before_title'  => '<h3 class="widget-title">',
						'after_title'   => '</h3>',
					);
					register_sidebar( $args );
				}
			}
		}

		/**
		 * Return the widget_areas array.
		 *
		 * @since 1.0.0
		 */
		public function get_widget_areas() {

			// If the single instance hasn't been set, set it now.
			if ( ! empty( $this->widget_areas ) ) {
				return $this->widget_areas;
			}

			$db = get_theme_mod( 'instock-pro-sidebars' );

			if ( !empty( $db ) ) {
				$this->widget_areas = array_unique( array_merge( $this->widget_areas, $db ) );
			}

			// Return widget areas
			return $this->widget_areas;
		}

		/**
		 * Before we create a new widget_area, verify it doesn't already exist. If it does, append a number to the name.
		 *
		 * @since 1.0.0
		 */
		public function instock_pro_delete_widget_area() {
			check_ajax_referer( 'delete-instock-pro-widget_area-nonce', 'tjextrasNonce' );
			if ( ! empty( $_REQUEST['name'] ) ) {
				$name = strip_tags( ( stripslashes( $_REQUEST['name'] ) ) );
				$this->widget_areas = $this->get_widget_areas();
				$key = array_search($name, $this->widget_areas );
				if ( $key >= 0 ) {
					unset( $this->widget_areas[$key] );
					$this->save_widget_areas();
				}
				echo 'widget_area-deleted';
			}
			die();
		}

		/**
		 * Enqueue JS for the customizer controls
		 *
		 * @since 1.0.0
		 */
		public function scripts() {

			// Load scripts
			wp_enqueue_script( 'instock-pro-sidebars', IP_URL . 'assets/js/sidebars.js', array( 'jquery' ), true );

			// Get widgets
			$widgets = array();
			if ( ! empty( $this->widget_areas ) ) {
				foreach ( $this->widget_areas as $widget ) {
					$widgets[$widget] = 1;
				}
			}

			// Localize script
			wp_localize_script(
				'instock-pro-sidebars',
				'tjExtrasWidgetAreasLocalize',
				array(
					'count'   => count( $this->orig ),
					'delete'  => __( 'Delete', 'instock-pro' ),
					'confirm' => __( 'Confirm', 'instock-pro' ),
					'cancel'  => __( 'Cancel', 'instock-pro' )
				)
			);
		}

		/**
		 * Adds inline CSS to style the widget form
		 *
		 * @since 1.0.0
		 */
		public function inline_css() { ?>

			<style type="text/css">
				body #instock-pro-add-widget h3 { text-align: center !important; padding: 15px 7px; font-size: 1.3em; margin-top: 5px; }
				body div#widgets-right .sidebar-instock-pro-custom .widgets-sortables { padding-bottom: 45px }
				body div#widgets-right .sidebar-instock-pro-custom.closed .widgets-sortables { padding-bottom: 0 }
				body .instock-pro-widget-area-footer { display: block; position: absolute; bottom: 0; left: 0; height: 40px; line-height: 40px; width: 100%; border-top: 1px solid #eee; }
				body .instock-pro-widget-area-footer > div { padding: 8px 8px 0 }
				body .instock-pro-widget-area-footer .instock-pro-widget-area-id { display: block; float: left; max-width: 48%; overflow: hidden; position: relative; top: -6px; }
				body .instock-pro-widget-area-footer .instock-pro-widget-area-buttons { float: right }
				body .instock-pro-widget-area-footer .description { padding: 0 !important; margin: 0 !important; }
				body div#widgets-right .sidebar-instock-pro-custom.closed .widgets-sortables .instock-pro-widget-area-footer { display: none }
				body .instock-pro-widget-area-footer .instock-pro-widget-area-delete { display: block; float: right; margin: 0; }
				body .instock-pro-widget-area-footer .instock-pro-widget-area-delete-confirm { display: none; float: right; margin: 0 5px 0 0; }
				body .instock-pro-widget-area-footer .instock-pro-widget-area-delete-cancel { display: none; float: right; margin: 0; }
				body .instock-pro-widget-area-delete-confirm:hover:before { color: red }
				body .instock-pro-widget-area-delete-confirm:hover { color: #000 }
				body .instock-pro-widget-area-delete:hover:before { color: #888 }
				body .activate_spinner { display: block !important; position: absolute; top: 10px; right: 4px; background-color: #ECECEC; }
				body #instock-pro-add-widget form { text-align: center }
				body #widget_area-instock-pro-custom,
				body #widget_area-instock-pro-custom h3 { position: relative }
				body #instock-pro-add-widget p { margin-top: 0 }
				body #instock-pro-add-widget { margin: 10px 0 0; position: relative; }
				body #instock-pro-add-widget-input { max-width: 95%; padding: 8px; margin-bottom: 14px; margin-top: 3px; text-align: center; }
			</style>

		<?php }

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			static $instance = null;
			if ( is_null( $instance ) ) {
				$instance = new self;
				$instance->setup_actions();
			}
			return $instance;
		}

		/**
		 * Constructor method.
		 *
		 * @since  1.0.0
		 * @access private
		 * @return void
		 */
		private function __construct() {}

	}

	Instock_Pro_Sidebars::get_instance();

}
